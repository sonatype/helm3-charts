<!--

    Sonatype Nexus (TM) Open Source Version
    Copyright (c) 2008-present Sonatype, Inc.
    All rights reserved. Includes the third-party code listed at http://links.sonatype.com/products/nexus/oss/attributions.

    This program and the accompanying materials are made available under the terms of the Eclipse Public License Version 1.0,
    which accompanies this distribution and is available at http://www.eclipse.org/legal/epl-v10.html.

    Sonatype Nexus (TM) Professional Version is available from Sonatype, Inc. "Sonatype" and "Sonatype Nexus" are trademarks
    of Sonatype, Inc. Apache Maven is a trademark of the Apache Software Foundation. M2eclipse is a trademark of the
    Eclipse Foundation. All other trademarks are the property of their respective owners.

-->

# Helm Chart for High Availability (HA) and Resilient Deployments

This Helm chart configures the Kubernetes resources that are needed for HA or resilient Nexus Repository Pro deployments in AWS, Azure, or on-premises.

- Have an idea for an improvement? Pro customers can submit ideas through [Sonatype's Ideas portal](https://ideas.sonatype.com/).
- If you encounter any problems/issues with the helm chart, please contact Sonatype support as support@sonatype.com

> **_NOTE:_** Sonatype does not support or plan to support using a Helm chart for deployments using embedded databases, which includes all OSS deployments. Using Kubernetes to manage an application with an embedded database is a leading cause of corruption, outages, and data loss.

---

# Pre-requisites
> **_Note:_**  Before upgrading your Nexus Repository instance, review the [Nexus Repository Release Notes](https://help.sonatype.com/en/release-notes.html) to evaluate any potential breaking changes.

Also be sure to review our [HA system requirements help documentation](https://help.sonatype.com/en/system-requirements-for-high-availability-deployments.html) and ensure that each instance meets our [normal Nexus Repository system requirements](https://help.sonatype.com/repomanager3/product-information/system-requirements).

### Nexus Repository Pro License
This Helm chart is designed for Sonatype Nexus Repository Pro deployments with a valid Pro license.

### Sticky Sessions for Load Balancers/Ingress
> **_NOTE:_** Configuration of sticky sessions is not supported in this chart. If you require sticky sessions, you will need to configure this in your load balancer or ingress controller as applicable.

### Storage
The default configuration uses an emptyDir volume for storing Nexus Repository logs. However, this is only for demonstration purposes. For production, we strongly recommend that
you configure dynamic provisioning of persistent storage bound to a shared location, such as EFS/Azure File/NFS, which is accessible to all actives nodes in your Kubernetes cluster. 

> **_Note:_**  Versions **66.0.0 and older** of this chart only supported local storage (e.g., EBS, Azure Disk, locally attached disks for on-prem deployments). 
> 
> From version **68.0.0+**, we recommend and support using **shared storage** (e.g., EFS, Azure File, NFS for on-prem deployments). However, this chart is still compatible with local storage.

#### Continuing to use EBS/Azure Disk/on-prem local disk storage in versions 68.0.0+ - **(Not recommended)**
If you wish to continue using EBS/Azure Disk/on-prem local disk storage, you can do so as follows:
* Ensure the appropriate Container Storage Interface (CSI) driver(s) are installed on the Kubernetes cluster for your chosen cloud deployment.
* Set `pvc.volumeClaimTemplate.enabled` to `true`
* Set `pvc.accessModes` to `ReadWriteOnce`
* Set `pvc.storageSize` to the desired size of the volume. E.g., `50Gi`
* To use a built-in storage class, set `storageClass.name` to `gp2`, `managed-premium` or `premium-rwo` for EKS, AKS and GKE respectively. For  on-prem deployments specify the name of your custom storage class.
* Set `volumeBindingMode` to `WaitForFirstConsumer`
* Set `reclaimPolicy` to `Retain` or `Delete` depending on your requirements
* To use a custom storage class, in addition to the above:
  * Set `storageClass.enabled` to `true`
  * Set the `storageClass.provisioner` to the appropriate value (see the documentation for your storage provider for more details). E.g., `ebs.csi.aws.com`, `disk.csi.azure.com` or `pd.csi.storage.gke.io` for EKS, AKS and GKE respectively. For on-prem deployments:`see the CSI driver documentation for your storage provider` E.g., for local static provisioner see https://github.com/kubernetes-sigs/sig-storage-local-static-provisioner
  * Additional parameters can be set as needed for your custom storage class using the `storageClass.parameters` field.

#### Migrating from local storage (i.e., EBS/Azure Disk/local disk) to shared storage (i.e., EFS/Azure File/NFS) for storing Nexus Repository logs

If you have installed version 66.0.0 or older of the nxrm-ha chart and wish to switch to using shared storage for Nexus Repository logs, please do as follows:

1. Back up all of your Nexus Repository pods' logs by logging in and generating a support zip for each one (see our [support zip help documentation](https://help.sonatype.com/en/support-features.html#creating-a-support-zip-in-a-high-availability-environment) to learn how).
2. Scale statefulset replicas to zero using commands like the following:
   * `kubectl get statefulsets -n nexusrepo`
   * `kubectl scale statefulsets -n nexusrepo <stateful set name> --replicas=0`
3. After scaling statefulset replicas to zero, delete the statefulset using a command like the following:
   *`kubectl delete statefulsets -n nexusrepo <stateful set name>`
4. Delete EBS/Azure disk/local disk PVCs using commands like the following: 
   * `kubectl get pvc -n nexusrepo`
   * `kubectl delete pvc -n nexusrepo <pvc 1> <pvc 2> <pvc n>`
   * If you have a custom storage class for EBS PVC/PV pair, delete that storage class as well.
4. Upgrade to the new version (68.0.0) of the nxrm-ha helm chart by taking the following steps:
   * Provision your shared storage (e.g., EFS/Azure File/NFS), and set appropriate permissions.
   * Update your custom values.yaml file for shared storage as detailed in the applicable section below for configuring dynamic persistent volume provisioning for your selected storage option. 
   * Run helm upgrade: `helm upgrade nxrm sonatype/nxrm-ha -f <your values.yaml> --version 68.0.0`
   * Scale replicas as needed.
5. Confirm all Nexus Repository pods start up and create new PVCs.
   * Confirm new PVCs were created and that they are bound appropriately depending on your configuration (i.e., EFS access points/Azure File shares/NFS mounts):
      * `kubectl get pvc -n nexusrepo` 
      * `kubectl describe pvc -n nexusrepo nexus-data-nxrm-nxrm-ha-0` 
      * `kubectl describe pvc -n nexusrepo nexus-data-nxrm-nxrm-ha-1`
      * Check that the `volume.beta.kubernetes.io/storage-provisioner` annotation in the PVC description is representative of your configuration (i.e., EFS/Azure File/NFS provisioner).
   * Confirm pods are up and running using commands like the following:
      * `kubectl get pods -n nexusrepo` 
      * `kubectl logs -n nexusrepo nxrm-nxrm-ha-0 -f` 
      * `kubectl logs -n nexusrepo nxrm-nxrm-ha-1 -f` 
      * `kubectl logs -n nexusrepo nxrm-nxrm-ha-2 -f`

#### Migrating from statefulset.name to nameOverride/fullnameOverride

If you have used the `statefulset.name` parameter in version 87.1.0 or earlier, this parameter has been removed in favor of the standard Helm naming conventions.

**What changed:**
- The `statefulset.name` parameter has been removed
- Use `nameOverride` or `fullnameOverride` instead for controlling resource names

**Migration steps:**

1. If you were using `statefulset.name` in your values.yaml, you need to update your configuration:

   **Old configuration (version ≤ 87.1.0):**
   ```yaml
   statefulset:
     name: nxrm-statefulset
   ```

   **New configuration (version ≥ 88.0.0):**
   ```yaml
   # Option 1: Use nameOverride (appends to release name)
   nameOverride: "nxrm-ha"
   # Results in: <release-name>-nxrm-ha

   # Option 2: Use fullnameOverride (complete name override)
   fullnameOverride: "nxrm-statefulset"
   # Results in: nxrm-statefulset
   ```

2. **Important:** If you need to maintain the exact same StatefulSet name as before, use `fullnameOverride` with your previous `statefulset.name` value.

3. Update your helm deployment with the new values:
   ```bash
   helm upgrade nxrm sonatype/nxrm-ha -f <your updated values.yaml> --version <new-version>
   ```

#### Cloud deployments (AWS/Azure/GCP)
* Ensure the appropriate Container Storage Interface (CSI) driver(s) are installed on the Kubernetes cluster for your chosen cloud deployment.
  * For AWS, see our [documentation on high availability deployments in AWS](https://help.sonatype.com/en/option-3---high-availability-deployment-in-amazon-web-services--aws-.html)
  * For Azure, see our [documentation on high availability deployments in Azure](https://help.sonatype.com/en/option-4---high-availability-deployment-in-azure.html)
  * For GCP, see our [documentation on high availability deployments in GCP](https://help.sonatype.com/en/option-4---high-availability-deployment-in-gcp.html)

#### On-premises deployments
1. Set up an NFS server and make it accessible to all worker nodes in your Kubernetes cluster.
2. See our [documentation on on-premises high availability deployments using Kubernetes](https://help.sonatype.com/en/option-2---on-premises-high-availability-deployment-using-kubernetes.html) for more information


### Ephemeral Storage for Logs and Support Content

By default, Nexus Repository logs (`/nexus-data/log`) and support content (`/nexus-data/tmp`) are stored inside the main `nexus-data` PVC. If you are already forwarding logs to a centralized system (e.g., AWS CloudWatch via Fluent Bit), you can redirect these paths to cheap, ephemeral (`emptyDir`) storage instead. This reduces PVC size requirements and storage costs, since the data does not need to survive a pod restart.

> **_IMPORTANT:_** Ephemeral storage is wiped when a pod is restarted or rescheduled. Only enable these options if you have a log forwarding solution (e.g., Fluent Bit → CloudWatch) already in place. If you enable ephemeral log storage without a log forwarder, logs will be lost on pod restart.

#### Enabling ephemeral log storage

In your values.yaml, set:

```yaml
ephemeralStorage:
  logs:
    enabled: true
    sizeLimit: "10Gi"      # adjust to your expected log volume
    path: "/nexus-data/log" # must be a subdirectory of /nexus-data
```

#### Enabling ephemeral support content storage

```yaml
ephemeralStorage:
  supportContent:
    enabled: true
    sizeLimit: "50Gi"      # adjust to your expected support zip volume
    path: "/nexus-data/tmp" # must be a subdirectory of /nexus-data
```

Both features are independent — you can enable one without the other.

> **_NOTE:_** The `path` value must be a subdirectory of `/nexus-data`, not `/nexus-data` itself. Setting `path` to `/nexus-data` will cause a Helm validation error because that path is reserved for the main PVC.

#### Migration notes for existing users

Existing users are unaffected — both `ephemeralStorage.logs.enabled` and `ephemeralStorage.supportContent.enabled` default to `false`. No action is required if you do not want to use ephemeral storage.


## Format Limitations
HA supports all formats that PostgreSQL supports.


## Deployment Configuration

### Secrets
The chart requires three secrets namely:
* License secret: stores your Nexus Repository Pro license
* Database secret: stores your database credentials: username, password and host
* Initial admin password secret: stores your initial admin password for Nexus Repository


#### Injecting required secrets into your Nexus Repository pod
The chart provides fours ways of injecting secrets into your Nexus Repository pod namely:
* [External secret operator](https://external-secrets.io/latest/): recommended as it supports several external secret stores (AWS, Azure, GCP etc).
  * Irrespective of whether you're installing on AWS/Azure, the following steps are needed to configure the nxrm-ha helm chart to use the External Secrets Operator:
    - [Install external secret operator](https://external-secrets.io/latest/)
    - Create your secrets in your external secret store (e.g. AWS Secrets Manager, Azure Key Vault, Google Secret Manager etc)
    - In your values.yaml:
        - Set `externalsecrets.enabled`
        - Set the `externalsecrets.secretstore.spec` to the correct one (e.g. AWS, Azure, GCP, HashiCorp Vault) for your provider. (There are examples for AWS, Azure, GCP in the default values.yaml provided with this helm chart). See https://external-secrets.io/latest/ for more examples.
        - Set the `externalsecrets.secrets.database.providerSecretName` to the name of the secret containing your database credentials in your external secret store. E.g. if using AWS, this should be the name of the secret in your AWS Secrets Manager. If using Azure, this should be the name of the secret in your Azure Key Vault
        - Set the `externalsecrets.secrets.database.dbUserKey` to the name of the key in the secret which contains your database username.
        - Set the `externalsecrets.secrets.database.dbPasswordKey` to the name of the key in the secret which contains your database password.
        - Set the `externalsecrets.secrets.database.dbHostKey` to the name of the key in the secret which contains your database host.
        - Set the `externalsecrets.secrets.admin.providerSecretName` to the name of the secret containing your Nexus Repository admin password in your external secret store. E.g. if using AWS, this should be the name of the secret in your AWS Secrets Manager. If using Azure, this should be the name of the secret in your Azure Key Vault
        - Set the `externalsecrets.secrets.admin.adminPasswordKey` to the name of the key in the secret which contains your initial Nexus Repository admin password.
        - Set the `externalsecrets.secrets.license.providerSecretName` to the name of the secret containing your Nexus Repository license in your external secret store. E.g. if using AWS, this should be the name of the secret in your AWS Secrets Manager. If using Azure, this should be the name of the secret in your Azure Key Vault
        - **For HashiCorp Vault KV secrets**: If your license is stored as a key-value pair in HashiCorp Vault (KV v2), you need to set additional parameters:
          - Set `externalsecrets.secrets.license.valueIsJson` to `true`
          - Set `externalsecrets.secrets.license.licenseKey` to the key name inside the KV secret that contains your license (e.g., `nexus-repo-license.lic`)
        - Ensure `secret.azure.nexusSecret.enabled` and `azure.keyvault.enabled` are `false`

* [Secret Store CSI Driver](https://github.com/kubernetes-sigs/secrets-store-csi-driver): If you're running on AWS or Azure and do not wish to use the external secrets operator, 
 you can use the secret store csi driver configuration. See [secretprovider.yaml](templates%2Fsecretprovider.yaml) and configuration table below for more details.
* Use the provided secrets templates:
  * [database-secret.yaml](templates%2Fdatabase-secret.yaml)
  * [license-config-mapping.yaml](templates%2Flicense-config-mapping.yaml)
  * [nexus-admin-secret.yaml](templates%2Fnexus-admin-secret.yaml)

### AWS
* Set `aws.enabled` to `true`.

#### Configuration for dynamic persistent volume provisioning
* Set `storageClass.enabled` to `true`
* Set `pvc.accessModes` to `ReadWriteMany`
* Set `storageClass.provisioner` to `efs.csi.aws.com`
* Set `storageClass.parameters` to
    ```
       provisioningMode: efs-ap 
       fileSystemId: "<your efs file system id>"
       directoryPerms: "700"
    ```
* Set `pvc.volumeClaimTemplate.enabled` to `true`

#### Secrets
If you do not wish to the [external secrets operator](https://external-secrets.io/latest/) for providing your secrets into your Nexus Repository pods, then you may use AWS Secret Manager directly.
AWS Secret Manager is disabled by default. If you would like to store your database secrets and license in AWS Secrets Manager, do as follows:
* Set `aws.secretmanager.enabled` to `true`.
   * Database credentials:
      * Store database credentials (i.e., host, user and password) in AWS secret manager.
      * In your values.yaml, do the following:
         * Set the keys and aliases to use for getting the database credentials from secrets manager:  
           `db:
           user: username
           userAlias: nxrm_db_user
           password: password
           passwordAlias: nxrm_db_password
           host: host
           hostAlias: nxrm_db_host`
            * Update the `secret.aws.rds.arn` to your Secret Manager ARN containing database credentials.
   * Initial Nexus Repository Admin Password
      * Store initial Nexus repository Admin password in AWS Secrets Manager.
      * Set the `secret.nexusAdmin.name` to the key you used in Secrets Manager.
      * Set the `secret.nexusAdmin.alias` to the alias you would like the helm chart to use.
      * Update the `secret.aws.adminpassword.arn` to your Secret Manager ARN containing initial admin password.
   * License
      * Store your Nexus Repository Pro license in AWS Secrets Manager.
      * Update the `secret.aws.license.arn` to your Secret Manager ARN containing your Nexus Repository Pro license.
  * Encryption Keys
    * Store the json file containing your encryption keys in AWS Secrets Manager
    * Set `secret.aws.nexusSecret.enabled` and `secret.nexusSecret.enabled` to true
    * Set `secret.aws.nexusSecret.arn` to the ARN of your secret in AWS Secrets Manager
    * Ensure `secret.azure.nexusSecret.enabled` and `azure.keyvault.enabled` are false

##### External Secrets Operator
- Ensure you have installed the [external secrets operator](https://external-secrets.io/latest/)
- Ensure you have granted the necessary permissions for accessing your external secret store:
- You'll need an IAM role with necessary permissions and associate that IAM role with the service account used by your pods:
- See [External secrets operator EKS service account credentials](https://external-secrets.io/latest/provider/aws-secrets-manager/#eks-service-account-credentials) for more details.

### Azure
* Set `azure.enabled` to `true`.

#### Configuration for dynamic persistent volume provisioning
You can either use one of the built-in storage classes for Azure File or create your own storage class.

##### Using built-in storage class
* Ensure you have enabled the built-in storage classes on your AKS cluster. For more information, see the Azure file dynamic provisioning section of [our documentation on high availability deployments in Azure](https://help.sonatype.com/en/option-4---high-availability-deployment-in-azure.html)
* Set `storageClass.enabled` to `false`
* Set `pvc.accessModes` to `ReadWriteMany`
* Set `storageClass.name` to one of the in-built storage classes for Azure file, such as azurefile-csi-premium, azurefile-premium, azurefile, or azurefile-csi
* Set `storageClass.provisioner` to `file.csi.azure.com`
* Set the `pvc.volumeClaimTemplate.enabled` parameter to `true`

##### Creating your own storage class
If you would like to create your own storage class instead of using the built-in ones, do as follows:

* Set `storageClass.enabled` to `true`
* Set `storageClass.name` to `nexus-log-storage`
* Set `storageClass.provisioner` to `file.csi.azure.com`
* Set `storageClass.mountOptions` to
    ```
   - dir_mode=0777
   - file_mode=0777
   - uid=0
   - gid=0
   - mfsymlinks
   - cache=strict # https://linux.die.net/man/8/mount.cifs
   - nosharesock 
    ```
* Set `storageClass.parameters.skuName` to `Premium_LRS`
* Set `pvc.volumeClaimTemplate.enabled` to `true`

#### Secrets
If you do not wish to the [external secrets operator](https://external-secrets.io/latest/) for providing your secrets into your Nexus Repository pods, then you may use Azure Key Vault directly.
Azure Key Vault is disabled by default. If you would like to store your database secrets and license in Azure Key Vault, do as follows:
* Set `azure.keyvault.enabled` to `true`.
   * Database credentials
      * Store database credentials (i.e., host, user, and password) in Azure Key Vault.
      * In your values.yaml, do the following:
         * Set the keys to use for getting the database credentials from Azure Key Vault:  
           `db:
           user: username
           password: password
           host: host`
         * Set the parameters nested in `secret.azure` accordingly.
   * Initial Nexus Repository Admin Password
      * Store initial Nexus repository Admin password in Azure Key Vault.
      * Set the `secret.nexusAdmin.name` to the key you used in Azure Key Vault.
   * License
      * Store your Nexus Repository Pro license in Azure Key Vault.
      * Set the `secret.license.name` to Azure Key Vault secret containing your Nexus Repository Pro license.
  * Encryption Keys
    * Store the json file containing your encryption keys in Azure Key Vault
    * Specify your key vault name in `secret.azuee.keyvaultName`
    * Set `secret.azure.nexusSecret.enabled` and `secret.nexusSecret.enabled` to true
    * Ensure `secret.aws.nexusSecret.enabled ` and `aws.secretmanager.enabled` are false


##### External Secrets Operator with Azure Workload Identity

This section covers using the [External Secrets Operator (ESO)](https://external-secrets.io/latest/) with Azure Workload Identity to securely pull secrets from Azure Key Vault into your NXRM deployment — without storing credentials in Kubernetes.

> **Backward compatibility:** The existing Secret Store CSI Driver path (`azure.keyvault.enabled: true`) remains fully supported. Both approaches can coexist in the same cluster on different namespaces. Choose the one that best fits your operational model.

###### Choosing between Secret Store CSI Driver and External Secrets Operator

| | Secret Store CSI Driver | External Secrets Operator (ESO) |
|---|---|---|
| **How secrets arrive** | Mounted as files in the pod via CSI volume | Synced into native Kubernetes Secrets |
| **Secret rotation** | Automatic via CSI driver poll interval | Automatic via ESO `refreshInterval` |
| **Multi-cloud support** | AWS + Azure only | AWS, Azure, GCP, HashiCorp Vault, and more |
| **Authentication** | Pod identity / managed identity | Workload Identity (recommended) |
| **Kubernetes-native** | Requires CSI driver DaemonSet | CRD-based, no DaemonSet needed |
| **Best for** | Simple single-cloud deployments | Multi-cloud, GitOps, or centralized secret management |

###### Prerequisites

Before enabling External Secrets with Workload Identity, ensure:

1. **AKS cluster** created with OIDC issuer and Workload Identity enabled:
   ```bash
   # For new clusters:
   az aks create -g <rg> -n <aks-name> --enable-oidc-issuer --enable-workload-identity

   # For existing clusters:
   az aks update -g <rg> -n <aks-name> --enable-oidc-issuer --enable-workload-identity
   ```

2. **External Secrets Operator** installed on the cluster:
   ```bash
   helm repo add external-secrets https://charts.external-secrets.io
   helm install external-secrets external-secrets/external-secrets \
     -n external-secrets --create-namespace
   ```

3. **Azure Key Vault** provisioned with the secrets NXRM needs (see step 5 below).

> **Important:** If any of these prerequisites are missing, the SecretStore will remain in `Ready=False` with no helpful error message. Verify all prerequisites before enabling ESO in the chart.

###### Step-by-step Azure setup

**1. Create a User Assigned Managed Identity:**
```bash
az identity create -g <rg> -n nxrm-wi
```

**2. Get the AKS OIDC issuer URL:**
```bash
OIDC_URL=$(az aks show -g <aks-rg> -n <aks-name> \
  --query oidcIssuerProfile.issuerUrl -o tsv)
```

**3. Create a federated credential mapping the Kubernetes ServiceAccount to the managed identity:**
```bash
az identity federated-credential create \
  -g <rg> \
  --identity-name nxrm-wi \
  -n fed-nxrm \
  --issuer "$OIDC_URL" \
  --subject system:serviceaccount:<namespace>:<sa-name> \
  --audience api://AzureADTokenExchange
```
Replace `<namespace>` with your NXRM namespace (e.g., `nexusrepo`) and `<sa-name>` with the ServiceAccount name you’ll use in values.yaml.

**4. Grant the managed identity `Key Vault Secrets User` on your Key Vault:**
```bash
az role assignment create \
  --role "Key Vault Secrets User" \
  --assignee-object-id <umi-principal-id> \
  --assignee-principal-type ServicePrincipal \
  --scope <kv-resource-id>
```
You can find the principal ID with:
```bash
az identity show -g <rg> -n nxrm-wi --query principalId -o tsv
```

**5. Populate Azure Key Vault with the required secrets:**

The chart’s ExternalSecrets reference these secrets by default:

| Chart secret | Default Key Vault secret name | Contains |
|---|---|---|
| Database credentials | `nxrm-db-user`, `nxrm-db-password`, `nxrm-db-host` | PostgreSQL user, password, host |
| Admin password | `nxrm-admin-password` | Initial NXRM admin password |
| License | `nxrm-license` | Nexus Repository Pro license (base64-encoded) |

> **Note:** Azure Key Vault secret names must be 1-127 characters containing only alphanumerics and dashes. The chart defaults (`username`, `password`, `host`) are overridable via `externalsecrets.secrets.*.providerSecretName` — use the names above or your own convention.

**6. Configure the Helm chart values:**
```yaml
serviceAccount:
  enabled: true
  name: <sa-name>
  labels:
    azure.workload.identity/use: "true"
  annotations:
    azure.workload.identity/client-id: <umi-client-id>
    azure.workload.identity/tenant-id: <tenant-id>

externalsecrets:
  enabled: true
  secretstore:
    spec:
      provider:
        azurekv:
          authType: WorkloadIdentity
          vaultUrl: https://<kv-name>.vault.azure.net/
          serviceAccountRef:
            name: <sa-name>
```

You can find the client ID and tenant ID with:
```bash
az identity show -g <rg> -n nxrm-wi --query ‘{clientId: clientId, tenantId: tenantId}’ -o table
```

###### Migrating from Secret Store CSI Driver to External Secrets Operator

If you are currently using the CSI Driver path (`azure.keyvault.enabled: true`) and want to migrate to ESO:

1. **Complete the Azure setup above** (steps 1–5) — the managed identity, federated credential, and Key Vault RBAC must be in place before switching.

2. **Update your values.yaml:**
   ```yaml
   # Disable the old CSI driver path
   azure:
     keyvault:
       enabled: false

   # Enable the new ESO path
   serviceAccount:
     enabled: true
     name: <sa-name>
     labels:
       azure.workload.identity/use: "true"
     annotations:
       azure.workload.identity/client-id: <umi-client-id>
       azure.workload.identity/tenant-id: <tenant-id>

   externalsecrets:
     enabled: true
     secretstore:
       spec:
         provider:
           azurekv:
             authType: WorkloadIdentity
             vaultUrl: https://<kv-name>.vault.azure.net/
             serviceAccountRef:
               name: <sa-name>
   ```

3. **Run `helm upgrade`** — the chart will create the SecretStore and ExternalSecret resources. ESO will sync your secrets from Key Vault into native Kubernetes Secrets.

4. **Verify:** Check that secrets are synced:
   ```bash
   kubectl get externalsecrets -n <namespace>
   # All should show STATUS = SecretSynced
   kubectl get secretstore -n <namespace>
   # Should show STATUS = Ready
   ```

5. **Clean up** (optional): Remove the CSI driver SecretProviderClass resources if no longer needed:
   ```bash
   kubectl delete secretproviderclass -n <namespace> --all
   ```

> **Note:** During migration, pods will restart to pick up the new secret source. Plan for a brief maintenance window in production.
                  
### GCP

 * Update values.yaml
   <a id="enable-service-account"></a>
   1. Enable service account  (you’ll need the name of the existing Google service account - there is a chapter below on how to create it)
  
       ```
         serviceAccount:
           enabled: true
           name: nexus-repository-deployment-sa
           labels: {}
           annotations:
             iam.gke.io/gcp-service-account: <service-account-name>@<project-id>.iam.gserviceaccount.com <- your GCP project service account e-mail
        
       ```

   2. Enable ingress 
        ```
        ingress:
          name: "nexus-ingress"
          enabled: true
        ```  
   3. Update ingress properties to correspond to GKE controller class https://cloud.google.com/kubernetes-engine/docs/how-to/load-balance-ingress#create-ingress 
        ```
        ingress:
          name: "nexus-ingress"
          enabled: true
          ...
          defaultRule: true
          additionalRules: null
          ingressClassName: gce
          ...
          annotations:
            kubernetes.io/ingress.class: "gce"
        ```
   4. Enable Nexus NodePort/ClusterIP service 
    
         ```
         service:  #Nexus Repo NodePort Service
           annotations: {}
           nexus:
             enabled: true
         ```

   5. Now you can update secrets separately (follow steps 6, 7, 8 below) 
      OR install ESO ([External Secret Operator]https://external-secrets.io/latest/introduction/getting-started/)
      ESO is the recommended approach for production.

        ```
        helm install external-secrets \
           external-secrets/external-secrets \
            -n external-secrets \
            --create-namespace
        ```
      and use external secrets from Google Secret Manager (https://external-secrets.io/latest/provider/google-secrets-manager/)
   

   6. Enable db secret 
        ```    
        secret:
          secretProviderClass: "secretProviderClass"
          provider: provider # e.g. aws, azure etc
          dbSecret:
            enabled: true # Enable to apply database-secret.yaml which allows you to specify db credentials
          db:
            user: nxrm
            userAlias: nxrm
            password: nxrm
            passwordAlias: nxrm
            host: 10.10.0.3
        ```

   7. (Optional) Set default password for Nexus instances 
        ```
          nexusAdminSecret:
            enabled: true # Enable to apply nexus-admin-secret.yaml which allows you to the initial admin password for nexus repository
            adminPassword: admin123 #You should change this when you login for the first time
        ```

   8. Set license (use base64 to encode file)  
        ```
          license:
            name: test-users.lic
            licenseSecret:
              enabled: true
              fileContentsBase64: cylwwtYx6Fg1CUa9yGqBuhGhgc4IS67Ha/+uvxSpA  == your base64 encoded license file == Gd7Z3+WS/0LIeugxSIa+ZDqtg7AR+U3d9ZJA==
              mountPath: /var/nexus-repo-license
        ```
      You can also specify the license file with your helm command as in:
      `--set-file secret.license.licenseSecret.file=<path to your license file>`

#### How to allow access to GCP credentials from deployed Kubernetes cluster (GKE)

  To allow a container in a GKE cluster node to access Application Default Credentials (ADC),
  you need to ensure that the GKE nodes have the necessary IAM roles and that the container is configured to use ADC. Here are the steps:

   1.  Ensure GKE Nodes Have the Necessary IAM Roles:
       When you create the cluster, ensure that you are using a service account that has required IAM roles for the GKE nodes
       NOTE: It's important to associate GCP service account with cluster node pool when you create node pool.
       Current GCP limitations doesn't allow to update service account for nodes, so you need to recreate the node pool if you need to change the service account.

       **Check step `2.c` if you need to create a new account**

       You may assign the necessary IAM roles to the service account. For example, if your application needs access to write in Google Cloud Storage,
       you would assign the `roles/storage.objectAdmin` role.
     
        ```
        gcloud projects add-iam-policy-binding <your-project-id> \
          --member "serviceAccount:<your-gke-node-service-account>" \
          --role "roles/storage.objectAdmin"
        ```

   2. Configure the GKE Cluster (if it's not configured at the creation) to Use Workload Identity:
      Workload Identity allows Kubernetes service accounts to act as Google service accounts. 
      This is the recommended way to provide credentials to applications running on GKE.
      We do not recommend using IAM principal identifiers to configure Workload Identity Federation,
      because there are a few limitations that apply to GoogleCloud Storage usage
      (you may need to enable uniform bucket-level access for your buckets etc…, more details here [Identity federation: products and limitations](https://cloud.google.com/iam/docs/federated-identity-supported-services)
      So we recommend to use this method:  [Alternative: link Kubernetes ServiceAccounts to IAM](https://cloud.google.com/kubernetes-engine/docs/how-to/workload-identity#kubernetes-sa-to-iam) 

   * 2.a
   Enable Workload Identity:

        ```    
        gcloud container clusters update <your-cluster-name> \
          --zone <your-cluster-zone> \
          --workload-pool=<your-project-id>.svc.id.goog
        ```
        ```
         gcloud container node-pools update NODEPOOL_NAME \
         --cluster=CLUSTER_NAME \
         --zone=COMPUTE_ZONE \
         --workload-metadata=GKE_METADATA
         ```
   * 2.b
   Create a Kubernetes Service Account:
    
         ```
         kubectl create serviceaccount <your-k8s-service-account>
         ```
   * 2.c
      Create a Google Service Account:
        ```
        gcloud iam service-accounts create <your-gsa-name> 
        ```
   * 2.d
      Grant required roles to your <your-gsa-name> account

        ```
         gcloud projects add-iam-policy-binding <your-project-id> \
         --member "serviceAccount:<your-gsa-name>@<your-project-id>.iam.gserviceaccount.com" \
         --role "roles/storage.admin"
        
        gcloud projects add-iam-policy-binding <your-project-id> \
        --member="serviceAccount:<your-gsa-name>@<your-project-id>.iam.gserviceaccount.com" \
        --role="roles/compute.viewer"
        
        // if your intent to use ESO   
        gcloud projects add-iam-policy-binding <your-project-id> \
        --member="serviceAccount:<your-gsa-name>@<your-project-id>.iam.gserviceaccount.com" \
        --role="roles/secretmanager.admin"
        
        // if your intent to use ESO    
        gcloud projects add-iam-policy-binding <your-project-id> \
        --member="serviceAccount:<your-gsa-name>@<your-project-id>.iam.gserviceaccount.com" \
        --role="roles/iam.serviceAccountTokenCreator"
        
        // if your intent to use Google Artifactory to store Nexus docker images for deploy
        gcloud projects add-iam-policy-binding <your-project-id> \
        --member="serviceAccount:<your-gsa-name>@<your-project-id>.iam.gserviceaccount.com" \
        --role="roles/artifactregistry.admin"
        ```
   * 2.e
      Allow the Kubernetes Service Account to Act As the Google Service Account:

        ```
        gcloud iam service-accounts add-iam-policy-binding <your-gsa-name>@<your-project-id>.iam.gserviceaccount.com \
          --role roles/iam.workloadIdentityUser \
          --member "serviceAccount:<your-project-id>.svc.id.goog[<your-namespace>/<your-k8s-service-account>]"
        ```
   * 2.f
        (Optional) Annotate the Kubernetes Service Account:
    
        ```
            kubectl annotate serviceaccount <your-k8s-service-account> \
            --namespace <your-namespace> \
            iam.gke.io/gcp-service-account=<your-gsa-name>@<your-project-id>.iam.gserviceaccount.com
        ```
        This step is optional - you may annotate the service account in `values.yaml` of the helm chart.
        For more information, see [Enable service account](#enable-service-account).

3. Deploy Your Application:

Ensure your application is configured to use ADC. When running on GKE with Workload Identity,
the ADC will automatically use the credentials provided by the annotated Kubernetes service account.

#### Configuration for dynamic persistent volume provisioning
* Ensure you have enabled the built-in storage classes on your GCP cluster. 
* You need to install Google CSI Filestore driver on your GKE cluster. 
* For more information, see the [GCP documentation](https://cloud.google.com/kubernetes-engine/docs/concepts/storage-overview#filestore)
* Set `storageClass.enabled` to `true`
* Set `pvc.accessModes` to `ReadWriteMany`
* Set `storageClass.provisioner` to `filestore.csi.storage.gke.io`
* Set `storageClass.parameters` to
    ```
         tier: enterprise
         multishare: "true"
    ```
* Set `pvc.volumeClaimTemplate.enabled` to `true`


##### External Secrets Operator
- Ensure you have installed the [external secrets operator](https://external-secrets.io/latest/)
- Ensure you have granted the necessary permissions for accessing your external secret store:
- You'll need to create a k8s service account and create a link between GCP service account and that Kubernetes service account:
    - See [Workload identity](https://external-secrets.io/latest/provider/google-secrets-manager/#workload-identity)
    - See 'Using Service Accounts directly' section [Using Service Accounts directly](https://external-secrets.io/latest/provider/google-secrets-manager/#using-service-accounts-directly)
- Enable the external secrets operator in your values.yaml:
    ```
    externalsecrets:
      enabled: true
      secretstore:
        name: nexus-secret-store
        spec:
          provider:
            gcpsecretsmanager:
              authType: WorkloadIdentity
              serviceAccountRef:
                name: nexus-repository-deployment-sa
    ```
- Ensure you have created the necessary secrets in GCP Secret Manager and have the necessary permissions to access them.
Check section above "Injecting required secrets into your Nexus Repository pod" for more details.

###### Guidance for setting up permissions needed for External Secrets Operator on GCP (EKS)

- For your GSP service account, you'll need to add an additional permissions to access the secret in GCP Secret Manager:

```
gcloud projects add-iam-policy-binding <your-project-id> \
--member="serviceAccount:<your-gsa-name>@<your-project-id>.iam.gserviceaccount.com" \
--role="roles/secretmanager.admin"

gcloud projects add-iam-policy-binding  <your-project-id> \
--member="serviceAccount:<your-gsa-name>@<your-project-id>.iam.gserviceaccount.com" \
--role="roles/iam.serviceAccountTokenCreator"
```



### On-premises
The chart doesn't install any cloud-specific resources when `aws.enabled` and `azure.enabled` are set to `false`.

#### Configuration for dynamic persistent volume provisioning
* You must already have an NFS Server, and it must be accessible to all worker nodes in your Kubernetes cluster.
* Install the [NFS subdir external provisioner](https://github.com/kubernetes-sigs/nfs-subdir-external-provisioner) using the [helm chart](https://github.com/kubernetes-sigs/nfs-subdir-external-provisioner?tab=readme-ov-file#with-helm).
  * At the time of writing, the helm installation command is as shown below.
  ```
  helm repo add nfs-subdir-external-provisioner https://kubernetes-sigs.github.io/nfs-subdir-external-provisioner/
  helm install nfs-subdir-external-provisioner nfs-subdir-external-provisioner/nfs-subdir-external-provisioner --set nfs.server=x.x.x.x --set nfs.path=/exported/path --set storageClass.create=true
  ``` 
  * We have added `--set storageClass.create=true` to the above command in order to create the default nfs storage class bundled with the helm chart.
  * Confirm that the pod for the nfs-subdir-external-provisioner is running:
    * At the time of writing, the pod had a 'app=nfs-subdir-external-provisioner' label. Thus, you can confirm it is running using the following: `kubectl get pods -A -l app=nfs-subdir-external-provisioner`
  * Confirm that the default storage class was created:
    * At the time of writing, the default storage class was 'nfs-client'. Thus, you can confirm its creation using `kubectl get sc nfs-client`
* For nxrm-ha helm chart, do the following:
  * Set `storageClass.enabled` to `false`
  * Set `storageClass.name` to `nfs-client`
  * Set `pvc.volumeClaimTemplate.enabled` to `true`


#### Secrets
* Database credentials
   * Set `secret.dbSecret.enabled` to `true` to enable [database-secret.yaml](nxrm-ha%2Ftemplates%2Fdatabase-secret.yaml) for storing database secrets.
   * Specify values for [database-secret.yaml](nxrm-ha%2Ftemplates%2Fdatabase-secret.yaml).
* Initial Nexus Repository Admin Password
   * Set `secret.nexusAdminSecret.enabled` to `true` to enable [nexus-admin-secret.yaml](nxrm-ha%2Ftemplates%2Fnexus-admin-secret.yaml) for storing initial Nexus Repository admin password secret.
   * Specify values for [nexus-admin-secret.yaml](nxrm-ha%2Ftemplates%2Fnexus-admin-secret.yaml).
* License
   * Set the `secret.license.licenseSecret.enabled` to `true` to enable [license-config-mapping.yaml](nxrm-ha%2Ftemplates%2Flicense-config-mapping.yaml) for storing your Nexus Repository Pro license.
   * Specify values for [license-config-mapping.yaml](nxrm-ha%2Ftemplates%2Flicense-config-mapping.yaml).
* Encryption Keys
    * Set `secret.nexusSecret.enabled` to true
    * Ensure `secret.azure.nexusSecret.enabled`, `azure.keyvault.enabled`, `secret.aws.nexusSecret.enabled` and `aws.secretmanager.enabled` are false

## Installing this Chart
You can install this helm chart from the git repository or sonatype helm index.

### From git repository
1. Check out this git repository.

2. Enter your custom values in the supplied values.yaml.  

3. Install this chart using the following:
  
```helm install nxrm nxrm3-ha-repository/nxrm-ha -f values.yaml```
  
4. Get the Nexus Repository link using the following:
  
```kubectl get ingresses -n nexusrepo```

### From Sonatype Helm index

1. Add the sonatype repo to your helm:

   ```helm repo add sonatype https://sonatype.github.io/helm3-charts/ ```

2. Enter your custom values in the supplied values.yaml.
3. Install this chart using the following:
```helm install nxrm sonatype/nxrm-ha -f values.yaml```
4. Get the Nexus Repository link using the following:
```kubectl get ingresses -n nexusrepo```

### Example helm install with options

Replace below commands with your actual values

#### OnPrem Deployments

```
helm install nxha1 \
--set storageClass.name=nfs \
--set secret.license.licenseSecret.enabled=true \
--set-file secret.license.licenseSecret.file=./nx-license-file.lic \
--set pvc.volumeClaimTemplate.enabled=true \
--set secret.dbSecret.enabled=true \
--set secret.db.host=postgres-host.mydomain \
--set secret.db.user=nexus \
--set secret.db.password=nexus123 \
--set secret.nexusAdminSecret.enabled=true \
--set secret.nexusAdminSecret.adminPassword="admin123" \
--set service.nexus.enabled=true \
sonatype/nxrm-ha
```

---

## Horizontal Pod Autoscaler (HPA)

The chart includes opt-in support for a `HorizontalPodAutoscaler` that automatically scales the NXRM StatefulSet based on CPU and memory utilization.

> **HPA is disabled by default.** Existing deployments are not affected.

### Prerequisites

1. **Kubernetes metrics-server** must be installed in your cluster. Without it the HPA controller cannot read resource utilization and will never scale.

   ```bash
   # Verify metrics-server is running
   kubectl top nodes
   ```

   If the command fails, install metrics-server:

   ```bash
   helm repo add metrics-server https://kubernetes-sigs.github.io/metrics-server/
   helm upgrade --install metrics-server metrics-server/metrics-server -n kube-system
   ```

2. **Clustered mode is required.** HPA is only supported when `statefulset.clustered: true` (the default). A `helm install` with `hpa.enabled: true` and `statefulset.clustered: false` will fail with a clear error.

3. **Do not set `statefulset.replicaCount` when using HPA.** HPA owns the replica count. Setting both will fail at install time with a clear error.

### Enabling HPA

```yaml
hpa:
  enabled: true
  minReplicas: 2                          # Must be >= 2 for HA
  maxReplicas: 10
  targetCPUUtilizationPercentage: 75
  targetMemoryUtilizationPercentage: 80
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
        - type: Percent
          value: 50
          periodSeconds: 60

# Remove or null out replicaCount when HPA is enabled
statefulset:
  replicaCount: null
```

### Disabling individual metrics

Both CPU and memory metrics are enabled by default. To use only one metric for scaling, set the other to `null`:

```yaml
hpa:
  enabled: true
  targetCPUUtilizationPercentage: 75
  targetMemoryUtilizationPercentage: null  # Memory-based scaling disabled
```

### Custom scale-up behavior

By default, scale-up uses Kubernetes defaults (no stabilization, immediate scale). To configure custom scale-up policies:

```yaml
hpa:
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
        - type: Percent
          value: 50
          periodSeconds: 60
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
        - type: Percent
          value: 100
          periodSeconds: 30
```

> **Note:** Scale-up behavior configuration is optional. If `behavior.scaleUp` is not set, Kubernetes applies its defaults (no stabilization window, immediate scaling up to maxReplicas).

### Why conservative scale-down policies?

NXRM is a stateful application connected to a shared PostgreSQL database. Aggressive scale-down carries two risks:

- **Database connection exhaustion** — each NXRM pod holds a connection pool. Scaling down too many pods at once can cause the remaining pods to saturate their pools as traffic is redistributed.
- **In-flight request loss** — artifact uploads and downloads in progress on a pod being terminated will fail.

The defaults mitigate both:

| Policy | Value | Reason |
|--------|-------|--------|
| `stabilizationWindowSeconds` | 300 | Waits 5 minutes before acting on a scale-down signal, smoothing transient dips |
| Max scale-down | 50% per 60 s | Never removes more than half the pod fleet in any one-minute window |

### Blob store rebalancing

> **Important:** NXRM does **not** automatically rebalance blob store content when pods are added or removed. Scale events affect request routing only. Plan blob store topology (e.g., S3/Azure Blob) before enabling HPA to avoid uneven storage usage across pods.

### Graceful shutdown

NXRM's `terminationGracePeriodSeconds` (default: `120 s`) gives in-flight requests time to complete before a pod is removed. If your workloads include large artifact uploads that can exceed 120 seconds, increase this value:

```yaml
statefulset:
  container:
    terminationGracePeriod: 300  # 5 minutes
```

#### preStop hooks

During HPA scale-down, Kubernetes sends a `SIGTERM` to the pod immediately. Without a `preStop` hook, in-flight requests (artifact uploads, downloads) may be interrupted before the pod has time to drain connections gracefully.

A `preStop` hook introduces a delay between the pod being marked for termination and receiving `SIGTERM`, giving load balancers and ingress controllers time to remove the pod from their routing tables:

```yaml
statefulset:
  container:
    preStop:
      command: ["/bin/sh", "-c", "sleep 15 && kill -TERM 1"]
```

**How it works:**
- Kubernetes marks the pod as `Terminating` and removes it from Service endpoints
- The `preStop` hook runs — sleeps 15 seconds to allow in-flight requests to complete and load balancers to update
- After the sleep, `SIGTERM` is sent to NXRM (PID 1), initiating a clean JVM shutdown
- The pod has the remaining `terminationGracePeriodSeconds` to finish shutting down

> **Tip:** Set `terminationGracePeriodSeconds` to at least `preStop sleep + expected shutdown time`. For example, a 15 s preStop sleep + 60 s JVM shutdown means `terminationGracePeriod` should be at least `90`.

### Minimum node sizing for HA + HPA

When using HPA with NXRM in HA mode, ensure your node pool has sufficient memory headroom for scale-up events. Each new replica requires its full `resources.requests.memory` allocation plus approximately 1 GiB of JVM overhead during cold-start.

**Recommended formula:**

```
Available node pool memory >= maxReplicas × (requests.memory + ~1 GiB JVM overhead)
```

If nodes are memory-constrained, new pods may OOM during cold-start and enter `CrashLoopBackOff`. In this state, HPA will intentionally refuse to scale further — it observes high CPU but recognizes that adding more pods that cannot boot would not help. The user-visible symptom is "HPA is not scaling even though CPU is high."

> **Minimum recommendation:** For HA deployments with HPA, plan for at least 8 GiB of available memory per NXRM replica in the node pool.

### Recommended starting targets

| Workload | CPU target | Memory target |
|----------|-----------|---------------|
| Read-heavy (proxy/hosted) | 70–80% | 80% |
| Write-heavy (CI uploads) | 60–70% | 75% |
| Mixed | 75% | 80% |

These are starting points. Monitor `kubectl top pods` after enabling HPA and adjust to your observed utilization patterns.

### Complementary node-level scaling

HPA scales pods within the existing node pool. To also scale the underlying nodes, configure your cloud provider's **Cluster Autoscaler** (AWS EKS, Azure AKS) or **Karpenter** alongside HPA.

---

## Nexus Secrets

---

## Health Check
You can use the following commands to perform various health checks:
  
See a list of releases:
  
  ```helm list```
  
 Check pods using the following:
  
  ```kubectl get pods -n nexusrepo```
  
Check the Nexus Repository logs with the following:
  
  ```kubectl logs <pod_name> -n nexusrepo nxrm-app```

---

## Uninstall
To uninstall the deployment, use the following:
  
  ```helm uninstall nxrm```
  
After removing the deployment, ensure that the namespace created by the helm chart is deleted and that Nexus Repository is not listed when using the following:
  
  ```helm list```

> **_Note:_** If you specified a namespace during chart installation (e.g., helm install nxrm3 . --create-namespace --namespace <customnamespace>), you will need to remove this namespace after running the uninstall command for the helm chart. The uninstall command will only remove the namespace created by the helm chart itself.

## Configuration

The following table lists the configurable parameters of the Nexus chart and their default values.

| Parameter                                                   | Description                                                                                                                                                                                                                                                                                                                                                                      | Default                                                                                                             |
|-------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| `namespaces.nexusNs.enabled`                                | Whether a namespace should be created for the Kubernetes resources needed Nexus Repository pod(s)                                                                                                                                                                                                                                                                                | `true`                                                                                                              |
| `namespaces.nexusNs.name`                                   | The namespace into which Kubernetes resources for Nexus Repository are installed into, if set to `''` the release namespace is used                                                                                                                                                                                                                                              | `nexusrepo`                                                                                                         |
| `namespaces.cloudwatchNs.enabled`                           | Whether a namespace should be created to install the Kubernetes resources needed by fluentbit                                                                                                                                                                                                                                                                                    | `false`                                                                                                             |
| `namespaces.cloudwatchNs.name`                              | The namespace into which Kubernetes resources for fluentbit are installed when fluentbit is enabled                                                                                                                                                                                                                                                                              | `amazon-cloudwatch`                                                                                                 |
| `namespaces.externaldnsNs`                                  | The namespace into which Kubernetes resources for externaldns are installed when externaldns is enabled                                                                                                                                                                                                                                                                          | `nexus-externaldns`                                                                                                 |
| `serviceAccount.enabled`                                    | Whether or not to create a Kubernetes Service Account object                                                                                                                                                                                                                                                                                                                     | `false`                                                                                                             |
| `serviceAccount.name`                                       | The name of a Kubernetes Service Account object to create in order for Nexus Repository pods to access resources as needed                                                                                                                                                                                                                                                       | `nexus-repository-deployment-sa`                                                                                    |
| `serviceAccount.annotations`                                | Annotations for the Kubernetes Service Account object.                                                                                                                                                                                                                                                                                                                           | `null`                                                                                                              |
| `azure.enabled`                                             | Set this to true when installing this chart on Azure                                                                                                                                                                                                                                                                                                                             | `false`                                                                                                             |
| `azure.keyvault.enabled`                                    | Set this to true when installing this chart on Azure and you would like the Nexus Repository pod to pull database credentials and license from azure Key Vault                                                                                                                                                                                                                   | `false`                                                                                                             |
| `aws.enabled`                                               | Set this to true when installing this chart on AWS                                                                                                                                                                                                                                                                                                                               | `false`                                                                                                             |
| `aws.clusterRegion`                                         | The AWS region containing your Kubernetes cluster.                                                                                                                                                                                                                                                                                                                               | `us-east-1`                                                                                                         |
| `aws.secretmanager.enabled`                                 | Set this to true when installing this chart on AWS and you would like the Nexus Repository pod to pull database credentials and license from AWS Secret Manager                                                                                                                                                                                                                  | `false`                                                                                                             |
| `aws.externaldns.enabled`                                   | Set this to true when installing this chart on AWS and you would like to setup [externaldns](https://github.com/kubernetes-sigs/external-dns)                                                                                                                                                                                                                                    | `false`                                                                                                             |
| `aws.externaldns.domainFilter`                              | Domain filter for [externaldns](https://github.com/kubernetes-sigs/external-dns)                                                                                                                                                                                                                                                                                                 | `example.com`                                                                                                       |
| `aws.externaldns.awsZoneType`                               | The hosted zone type. See [externaldns](https://github.com/kubernetes-sigs/external-dns)                                                                                                                                                                                                                                                                                         | `private`                                                                                                           |
| `aws.fluentbit.enabled`                                     | Set this to true when installing this chart on AWS and you would like to install Fluentbit so that Nexus Repository logs can be sent to AWS Cloud Watch                                                                                                                                                                                                                          | `false`                                                                                                             |
| `aws.fluentbit.fluentbitVersion`                            | The fluentbit version                                                                                                                                                                                                                                                                                                                                                            | `2.28.0`                                                                                                            |
| `aws.fluentbit.clusterName`                                 | The name of your Kubernetes cluster. This is required by fluentbit                                                                                                                                                                                                                                                                                                               | `nxrm-nexus`                                                                                                        |
| `nameOverride`                                              | Overrides the chart name used in resource naming. The StatefulSet and other resources will be named `<release-name>-<nameOverride>`.                                                                                                                                                                                                                                             | `""`                                                                                                                |
| `fullnameOverride`                                          | Fully overrides the generated name for all resources. When set, the StatefulSet and other resources will use this exact name (truncated to 63 characters). This takes precedence over `nameOverride`.                                                                                                                                                                            | `""`                                                                                                                |
| `statefulset.replicaCount`                                  | The desired number of Nexus Repository pods                                                                                                                                                                                                                                                                                                                                      | 3                                                                                                                   |
| `statefulset.clustered`                                     | Determines whether or not Nexus Repository should be run in clustered/HA mode. When this is set to false, the search differences [here](https://help.sonatype.com/repomanager3/planning-your-implementation/resiliency-and-high-availability/high-availability-deployment-options#HighAvailabilityDeploymentOptions-SearchFeatureDifferences) do not apply.                      | true                                                                                                                |
| `statefulset.additionalVolumes`                             | Additional volumes to associate with the Nexus Repository container                                                                                                                                                                                                                                                                                                              | `null`                                                                                                              |
| `statefulset.additionalVolumeMounts`                        | Additional volume mounts for the additional volumes associated with the Nexus Repository container                                                                                                                                                                                                                                                                               | `null`                                                                                                              |
| `statefulset.additionalContainers`                          | Additional containers to associate with the Nexus Repository pod                                                                                                                                                                                                                                                                                                                 | `null`                                                                                                              |
| `statefulset.annotations`                                   | Annotations to enhance statefulset configuration                                                                                                                                                                                                                                                                                                                                 | {}                                                                                                                  |
| `statefulset.podAnnotations`                                | Pod annotations                                                                                                                                                                                                                                                                                                                                                                  | {}                                                                                                                  |
| `statefulset.nodeSelector`                                  | Node selectors                                                                                                                                                                                                                                                                                                                                                                   | {}                                                                                                                  |
| `statefulset.hostAliases`                                   | Aliases for IPs in /etc/hosts                                                                                                                                                                                                                                                                                                                                                    | []                                                                                                                  |
| `statefulset.postStart.command`                             | Command to run after starting the container                                                                                                                                                                                                                                                                                                                                      | `null`                                                                                                              |
| `statefulset.preStart.command`                              | Command to run before starting the container                                                                                                                                                                                                                                                                                                                                     | `null`                                                                                                              |
| `statefulset.initContainers`                                | Init containers to run before main containers                                                                                                                                                                                                                                                                                                                                    | An init container which creates directories needed for logging and give the Nexus Repository user write permissions |
| `statefulset.container.image.repository`                    | The Nexus repository image registry URL                                                                                                                                                                                                                                                                                                                                          | sonatype/nexus3                                                                                                     |
| `statefulset.container.image.nexusTag`                      | The Nexus repository image tag                                                                                                                                                                                                                                                                                                                                                   | latest                                                                                                              |
| `statefulset.container.resources.requests.cpu`              | The minimum cpu the Nexus repository pod can request                                                                                                                                                                                                                                                                                                                             | 4                                                                                                                   |
| `statefulset.container.resources.requests.memory`           | The minimum memory the Nexus repository pod can request                                                                                                                                                                                                                                                                                                                          | 8Gi                                                                                                                 |
| `statefulset.container.resources.limits.cpu`                | The maximum cpu the Nexus repository pod may get.                                                                                                                                                                                                                                                                                                                                | 4                                                                                                                   |
| `statefulset.container.resources.limits.memory`             | The maximum memory the Nexus repository pod may get.                                                                                                                                                                                                                                                                                                                             | 8Gi                                                                                                                 |
| `statefulset.container.containerPort`                       | The Nexus Repository container's HTTP port                                                                                                                                                                                                                                                                                                                                       | 8081                                                                                                                |
| `statefulset.container.pullPolicy`                          | The Nexus Repository docker image pull policy                                                                                                                                                                                                                                                                                                                                    | IfNotPresent                                                                                                        |
| `statefulset.container.terminationGracePeriod`              | The time given for the pod to gracefully shut down                                                                                                                                                                                                                                                                                                                               | 120 seconds                                                                                                         |
| `statefulset.container.env.nexusDBName`                     | The name of the PostgreSQL database to use.                                                                                                                                                                                                                                                                                                                                      | nexus                                                                                                               |
| `statefulset.container.env.nexusDBPort`                     | The database port of the PostgreSQL database to use.                                                                                                                                                                                                                                                                                                                             | 5432                                                                                                                |
| `statefulset.container.env.install4jAddVmParams`            | Xmx and Xms settings for JVM                                                                                                                                                                                                                                                                                                                                                     | -Xms2703m -Xmx2703m                                                                                                 |
| `statefulset.container.env.jdbcUrlParams`                   | Additional parameters to append to the database url. Expected format is  `"?foo=bar&baz=foo"`                                                                                                                                                                                                                                                                                    | null                                                                                                                |
| `statefulset.container.additionalEnv`                       | Additional environment variables for the Nexus Repository container. You can also use this setting to override a default env variable by specifying the same key/name as the default env variable you wish override. Specify this as a block of name and value pairs (e.g., "<br/>additionalEnv:<br/>- name: foo<br/> value: bar<br/>- name: foo2<br/> value: bar2")             | null                                                                                                                |
| `statefulset.requestLogContainer.image.repository`          | Image registry URL for a container which tails Nexus Repository's request log                                                                                                                                                                                                                                                                                                    | busybox                                                                                                             |
| `statefulset.requestLogContainer.image.tag`                 | Image tag for a container which tails Nexus Repository's request log                                                                                                                                                                                                                                                                                                             | 1.33.1                                                                                                              |
| `statefulset.requestLogContainer.resources.requests.cpu`    | The minimum cpu the request log container can request                                                                                                                                                                                                                                                                                                                            | 0.1                                                                                                                 |
| `statefulset.requestLogContainer.resources.requests.memory` | The minimum memory the request log container can request                                                                                                                                                                                                                                                                                                                         | 256Mi                                                                                                               |
| `statefulset.requestLogContainer.resources.limits.cpu`      | The maximum cpu the request log container may get.                                                                                                                                                                                                                                                                                                                               | 0.2                                                                                                                 |
| `statefulset.requestLogContainer.resources.limits.memory`   | The maximum memory the request log container may get.                                                                                                                                                                                                                                                                                                                            | 512Mi                                                                                                               |
| `statefulset.auditLogContainer.image.repository`            | Image registry URL for a container which tails Nexus Repository's audit log                                                                                                                                                                                                                                                                                                      | busybox                                                                                                             |
| `statefulset.auditLogContainer.image.tag`                   | Image tagfor a container which tails Nexus Repository's audit log                                                                                                                                                                                                                                                                                                                | 1.33.1                                                                                                              |
| `statefulset.auditLogContainer.resources.requests.cpu`      | The minimum cpu the audit log container can request                                                                                                                                                                                                                                                                                                                              | 0.1                                                                                                                 |
| `statefulset.auditLogContainer.resources.requests.memory`   | The minimum memory the audit log container can request                                                                                                                                                                                                                                                                                                                           | 256Mi                                                                                                               |
| `statefulset.auditLogContainer.resources.limits.cpu`        | The maximum cpu the audit log container may get.                                                                                                                                                                                                                                                                                                                                 | 0.2                                                                                                                 |
| `statefulset.auditLogContainer.resources.limits.memory`     | The maximum memory the reauditquest log container may get.                                                                                                                                                                                                                                                                                                                       | 512Mi                                                                                                               |
| `statefulset.taskLogContainer.image.repository`             | Image registry URL for a container which aggregates and tails Nexus Repository's task log                                                                                                                                                                                                                                                                                        | busybox                                                                                                             |
| `statefulset.taskLogContainer.image.tag`                    | Image tag for a container which aggregates and tails Nexus Repository's task log                                                                                                                                                                                                                                                                                                 | 1.33.1                                                                                                              |
| `statefulset.taskLogContainer.resources.requests.cpu`       | The minimum cpu the task log container can request                                                                                                                                                                                                                                                                                                                               | 0.1                                                                                                                 |
| `statefulset.taskLogContainer.resources.requests.memory`    | The minimum memory the task log container can request                                                                                                                                                                                                                                                                                                                            | 256Mi                                                                                                               |
| `statefulset.taskLogContainer.resources.limits.cpu`         | The maximum cpu the task log container may get.                                                                                                                                                                                                                                                                                                                                  | 0.2                                                                                                                 |
| `statefulset.taskLogContainer.resources.limits.memory`      | The maximum memory the task log container may get.                                                                                                                                                                                                                                                                                                                               | 512Mi                                                                                                               |
| `statefulset.startupProbe.initialDelaySeconds`              | StartupProbe initial delay                                                                                                                                                                                                                                                                                                                                                       | 0                                                                                                                   |
| `statefulset.startupProbe.periodSeconds`                    | Seconds between polls                                                                                                                                                                                                                                                                                                                                                            | 10                                                                                                                  |
| `statefulset.startupProbe.failureThreshold`                 | Number of attempts before failure                                                                                                                                                                                                                                                                                                                                                | 180                                                                                                                 |
| `statefulset.startupProbe.timeoutSeconds`                   | Time in seconds after liveness probe times out                                                                                                                                                                                                                                                                                                                                   | 1                                                                                                                   |
| `statefulset.startupProbe.path`                             | Path for StartupProbe                                                                                                                                                                                                                                                                                                                                                            | /                                                                                                                   |
| `statefulset.livenessProbe.initialDelaySeconds`             | LivenessProbe initial delay                                                                                                                                                                                                                                                                                                                                                      | 0                                                                                                                   |
| `statefulset.livenessProbe.periodSeconds`                   | Seconds between polls                                                                                                                                                                                                                                                                                                                                                            | 60                                                                                                                  |
| `statefulset.livenessProbe.failureThreshold`                | Number of attempts before failure                                                                                                                                                                                                                                                                                                                                                | 6                                                                                                                   |
| `statefulset.livenessProbe.timeoutSeconds`                  | Time in seconds after liveness probe times out                                                                                                                                                                                                                                                                                                                                   | 1                                                                                                                   |
| `statefulset.livenessProbe.path`                            | Path for LivenessProbe                                                                                                                                                                                                                                                                                                                                                           | /                                                                                                                   |
| `statefulset.readinessProbe.initialDelaySeconds`            | ReadinessProbe initial delay                                                                                                                                                                                                                                                                                                                                                     | 0                                                                                                                   |
| `statefulset.readinessProbe.periodSeconds`                  | Seconds between polls                                                                                                                                                                                                                                                                                                                                                            | 60                                                                                                                  |
| `statefulset.readinessProbe.failureThreshold`               | Number of attempts before failure                                                                                                                                                                                                                                                                                                                                                | 6                                                                                                                   |
| `statefulset.readinessProbe.timeoutSeconds`                 | Time in seconds after readiness probe times out                                                                                                                                                                                                                                                                                                                                  | 1                                                                                                                   |
| `statefulset.readinessProbe.path`                           | Path for ReadinessProbe                                                                                                                                                                                                                                                                                                                                                          | /                                                                                                                   |
| `statefulset.imagePullSecrets`                              | The pull secret for private image registries                                                                                                                                                                                                                                                                                                                                     | `{}`                                                                                                                |
| `ingress.enabled`                                           | Whether or not to create the Ingress                                                                                                                                                                                                                                                                                                                                             | false                                                                                                               |
| `ingress.host`                                              | Ingress host                                                                                                                                                                                                                                                                                                                                                                     | `null`                                                                                                              |
| `ingress.hostPath`                                          | Path for ingress rules.                                                                                                                                                                                                                                                                                                                                                          | `/`                                                                                                                 |
| `ingress.dockerSubdomain`                                   | Whether or not to add rules for docker subdomains                                                                                                                                                                                                                                                                                                                                | `false`                                                                                                             |
| `ingress.defaultRule`                                       | Whether or not to add a default rule for the Nexus Repository Ingress which forwards traffic to a Service object                                                                                                                                                                                                                                                                 | `false`                                                                                                             |
| `ingress.additionalRules`                                   | Additional rules to add to the ingress                                                                                                                                                                                                                                                                                                                                           | `null`                                                                                                              |
| `ingress.incressClassName`                                  | The ingress class name e.g., nginx, alb etc.                                                                                                                                                                                                                                                                                                                                     | `null`                                                                                                              |
| `ingress.tls.secretName`                                    | The name of a Secret object in which to store the TLS secret for ingress                                                                                                                                                                                                                                                                                                         | `null`                                                                                                              |
| `ingress.tls.hosts`                                         | A list of TLS hosts                                                                                                                                                                                                                                                                                                                                                              | `null`                                                                                                              |
| `ingress.annotations`                                       | Annotations for the Ingress object                                                                                                                                                                                                                                                                                                                                               | `nil`                                                                                                               |
| `storageClass.enabled`                                      | Set to true if you'd like to create your own storage class for persistent volumes and persistent volume claims                                                                                                                                                                                                                                                                   | `false`                                                                                                             |
| `storageClass.name`                                         | The name of a storage class object to create                                                                                                                                                                                                                                                                                                                                     | `nexus-storage`                                                                                                     |
| `storageClass.provisioner`                                  | The name of a storage class provisioner                                                                                                                                                                                                                                                                                                                                          | `provisionerName`                                                                                                   |
| `storageClass.volumeBindingMode`                            | The volume binding mode for the storage class                                                                                                                                                                                                                                                                                                                                    | `WaitForFirstConsumer`                                                                                              |
| `storageClass.reclaimPolicy`                                | The reclaim policy for any volumes which use this storage class                                                                                                                                                                                                                                                                                                                  | `Retain`                                                                                                            |
| `storageClass.parameters`                                   | Volume parameters for the storage class                                                                                                                                                                                                                                                                                                                                          | `nil`                                                                                                               |
| `storageClass.allowVolumeExpansion`                         | Whether or not to allow more storage to be claimed by a Persistent Volume Claim                                                                                                                                                                                                                                                                                                  | `false`                                                                                                             |
| `storageClass.mountOptions`                                 | Mounting options for volumes using the storage class                                                                                                                                                                                                                                                                                                                             | `nil`                                                                                                               |
| `pvc.accessMode`                                            | The persistent volume claim access mode                                                                                                                                                                                                                                                                                                                                          | ReadWriteOnce                                                                                                       |
| `pvc.storage`                                               | The volume size to request for storing Nexus logs                                                                                                                                                                                                                                                                                                                                | 2Gi                                                                                                                 |
| `pvc.existingClaim`                       | The name of an existing Persistent Volume Claim to use for Nexus Repository data. **Important: This is only for single-instance deployments to provide resiliency. Do not use for high availability deployments.** | `null`               | 
| `pvc.volumeClaimTemplate.enabled`                           | You should set this property to true for cloud deployments in order to use dynamic volume provisioning to reserve volumes for Nexus Repository's logs. For on-premises deployment use [Local Persistence Volumen Static Provisioner](https://github.com/kubernetes-sigs/sig-storage-local-static-provisioner) to automatically create persistent volumes for pre-attached disks. | `false`                                                                                                             |
| `service.annotations`                                       | Common annotations for all Service objects (nexus, docker-registries, nexus-headless)                                                                                                                                                                                                                                                                                            | `{}`                                                                                                                |
| `service.nexus.enabled`                                     | Whether or not to create the Service object                                                                                                                                                                                                                                                                                                                                      | `false`                                                                                                             |
| `service.nexus.type`                                        | The type of the Kubernetes Service                                                                                                                                                                                                                                                                                                                                               | "NodePort"                                                                                                          |
| `service.nexus.protocol`                                    | The protocol                                                                                                                                                                                                                                                                                                                                                                     | TCP                                                                                                                 |
| `service.nexus.port`                                        | The port to listen for incoming requests                                                                                                                                                                                                                                                                                                                                         | `80`                                                                                                                |
| `service.headless.annotations`                              | Annotations for the headless service object                                                                                                                                                                                                                                                                                                                                      | `{}`                                                                                                                |
| `service.headless.publishNotReadyAddresses`                 | Whether or not the service to be discoverable even before the corresponding endpoints are ready                                                                                                                                                                                                                                                                                  | `true`                                                                                                              |
| `service.nexus.targetPort`                                  | The port to forward requests to                                                                                                                                                                                                                                                                                                                                                  | `8081`                                                                                                              |
 | `externalsecrets.enabled`                                   | Set this to true if https://external-secrets.io/latest/ is installed in your Kubernetes cluster and you would like to use it for providing needed secrets to your Nexus Repository pods                                                                                                                                                                                          |                                                                                                                     |
 | `externalsecrets.secretstore.spec`                          | Set this to the SecretStore configuration for your external secret store. See https://external-secrets.io/latest/ for examples.                                                                                                                                                                                                                                                  |                                                                                                                     |
 | `externalsecrets.secrets.database.providerSecretName`       | Set this to the name of the secret containing your database credentials in your external secret store. E.g. if using AWS, this should be the name of the secret in your AWS Secrets Manager. If using Azure, this should be the name of the secret in your Azure Key Vault                                                                                                       |                                                                                                                     |
 | `externalsecrets.secrets.database.dbUserKey`                | Set this to the name of the key in the secret which contains your database username.                                                                                                                                                                                                                                                                                             |                                                                                                                     |
 | `externalsecrets.secrets.database.dbPasswordKey`            | Set this to the name of the key in the secret which contains your database password.                                                                                                                                                                                                                                                                                             |                                                                                                                     |
 | `externalsecrets.secrets.database.dbHostKey`                | Set this to the name of the key in the secret which contains your database host.                                                                                                                                                                                                                                                                                                 |                                                                                                                     |
 | `externalsecrets.secrets.admin.providerSecretName`          | Set this to the name of the secret containing your Nexus Repository admin password in your external secret store. E.g. if using AWS, this should be the name of the secret in your AWS Secrets Manager. If using Azure, this should be the name of the secret in your Azure Key Vault                                                                                            |                                                                                                                     |
 | `externalsecrets.secrets.admin.adminPasswordKey`            | Set this to the name of the key in the secret which contains your which contains your initial Nexus Repository admin password.                                                                                                                                                                                                                                                   |                                                                                                                     |
 | `externalsecrets.secrets.license.providerSecretName`        | Set this to the name of the secret containing your Nexus Repository license in your external secret store. E.g. if using AWS, this should be the name of the secret in your AWS Secrets Manager. If using Azure, this should be the name of the secret in your Azure Key Vault                                                                                                   |                                                                                                                     |
 | `externalsecrets.secrets.license.valueIsJson`               | Set to `true` when using HashiCorp Vault KV secrets where the license is stored as a key-value pair. When `true`, the `licenseKey` parameter is used to extract the license from the JSON object.                                                                                                                                                                                 | `false`                                                                                                             |
 | `externalsecrets.secrets.license.licenseKey`                | The key name inside the KV secret that contains the license content. Only used when `valueIsJson` is `true`.                                                                                                                                                                                                                                                                      | `nexus-repo-license.lic`                                                                                            |
| `secret.secretProviderClass`                                | The secret provider class for Kubernetes secret store object. See [secret.yaml](templates%2Fsecret.yaml). Set this when using AWS Secret Manager or Azure Key Vault                                                                                                                                                                                                              | secretProviderClass                                                                                                 |
| `secret.provider`                                           | The provider (e.g. azure, aws etc) for Kubernetes secret store object. Set this when using AWS Secret Manager or Azure Key Vault                                                                                                                                                                                                                                                 | provider                                                                                                            |
| `secret.dbSecret.enabled`                                   | Whether or not to install [database-secret.yaml](templates%2Fdatabase-secret.yaml). Set this to `false` when using AWS Secret Manager or Azure Key Vault                                                                                                                                                                                                                         | `false`                                                                                                             |
| `secret.db.user`                                            | The key for secret in AWS Secret manager or Azure Key Vault which contains the database user name. Otherwise if `secret.dbSecret.enabled` is true, set this to the database user name.                                                                                                                                                                                           | nxrm_db_user                                                                                                        |
| `secret.db.user-alias`                                      | Applicable to AWS Secret Manager only. An alias to use for the database user secret retrieved from AWS Secret manager.                                                                                                                                                                                                                                                           | nxrm_db_user_alias                                                                                                  |
| `secret.db.password`                                        | The key for secret in AWS Secret manager or Azure Key Vault which contains the database password. Otherwise if `secret.dbSecret.enabled` is true, set this to the database password.                                                                                                                                                                                             | nxrm_db_password                                                                                                    |
| `secret.db.password-alias`                                  | Applicable to AWS Secret Manager only. An alias to use for the database password secret retrieved from AWS Secret manager.                                                                                                                                                                                                                                                       | nxrm_db_password_alias                                                                                              |
| `secret.db.host`                                            | The key for secret in AWS Secret manager or Azure Key Vault which contains the database host URL. Otherwise if `secret.dbSecret.enabled` is true, set this to the database host URL.                                                                                                                                                                                             | nxrm_db_host                                                                                                        |
| `secret.db.host-alias`                                      | Applicable to AWS Secret Manager only. An alias to use for the database host secret retrieved from AWS Secret manager.                                                                                                                                                                                                                                                           | nxrm_db_host_alias                                                                                                  |
| `secret.nexusAdminSecret.enabled`                           | Whether or not to install [nexus-admin-secret.yaml](templates%2Fnexus-admin-secret.yaml). Set this to `false` when using AWS Secret Manager or Azure Key Vault.                                                                                                                                                                                                                  | `false`                                                                                                             |
| `secret.nexusAdminSecret.adminPassword`                     | When `secret.nexusAdminSecret.enabled` is true, set this to the initial admin password for Nexus Repository.  Otherwise ignore.                                                                                                                                                                                                                                                  | yourinitialnexuspassword                                                                                            |
| `secret.nexusAdmin.name`                                    | The key for secret in AWS Secret manager or Azure Key Vault which contains the initial Nexus Repository admin password. Otherwise if `secret.nexusAdminSecret.enabled` is true, then set this to the name for [nexus-admin-secret.yaml](templates%2Fnexus-admin-secret.yaml)                                                                                                     | `nexusAdminPassword`                                                                                                |
| `secret.nexusAdmin.alias`                                   | Applicable to AWS Secret Manager only. An alias to use for the initial Nexus Repository admin password secret retrieved from AWS Secret manager.                                                                                                                                                                                                                                 | `admin-nxrm-password-alias`                                                                                         |
| `secret.license.name`                                       | The name for [license-config-mapping.yaml](templates%2Flicense-config-mapping.yaml) for storing Nexus Repository license. This is an alternative way of specifying your Nexus Repository Pro license. Use this option when not using Azure Key Vault or AWS Secret Manager                                                                                                       | nexus-repo-license.lic                                                                                              |
| `secret.license.licenseSecret.enabled`                      | Whether or not to install [license-config-mapping.yaml](templates%2Flicense-config-mapping.yaml)                                                                                                                                                                                                                                                                                 | `false`                                                                                                             |
| `secret.license.licenseSecret.file`                         | Name of the nexus file with path. Set this if you're not using AWS Secret Manager or Azure Key Vault to store your Nexus Repository Pro license.                                                                                                                                                                                                                                 | your_license_file_with_full_path                                                                                    |
| `secret.license.licenseSecret.fileContentsBase64`           | A base64 representation of your Nexus Repository Pro license. Set this if you're not using AWS Secret Manager or Azure Key Vault to store your Nexus Repository Pro license.                                                                                                                                                                                                     | your_license_file_contents_in_base_64                                                                               |
| `secret.license.licenseSecret.mountPath`                    | The path where your Nexus Repository Pro license is mounted in the Nexus Repository container                                                                                                                                                                                                                                                                                    | /var/nexus-repo-license                                                                                             |
| `secret.nexusSecret.name`                                   | The name of the [nexus-secret-mapping.yaml](templates%2Fnexus-secret-mapping.yaml) secret for storing Nexus Repository encryption secrets.                                                                                                                                                                                                                                       | nexus-secret.json                                                                                                   |
| `secret.nexusSecret.enabled`                                | Whether or not to install [nexus-secret-mapping.yaml](templates%2Fnexus-secret-mapping.yaml) secret                                                                                                                                                                                                                                                                              | `false`                                                                                                             |
| `secret.nexusSecret.secretKeyfile`                          | The name of a file which contains a JSON document of keys to be used for encryption                                                                                                                                                                                                                                                                                              | secretfileName                                                                                                      |
| `secret.nexusSecret.mountPath`                              | The path where your JSON document of keys is mounted in the Nexus Repository container                                                                                                                                                                                                                                                                                           | /var/nexus-repo-secrets                                                                                             |
| `secret.azure.userAssignedIdentityID`                       | A managed identity or service principal that has `secrets management` access to the key vault. Only applicable if this chart is installed on Azure and you've stored database credentials, Nexus Repository initial admin password and your Nexus Repository Pro license in Azure Key Vault.                                                                                     | userAssignedIdentityID                                                                                              |
| `secret.azure.tenantId`                                     | Your Azure tenant id. Only applicable if this chart is installed on Azure and you've stored database credentials, Nexus Repository initial admin password and your Nexus Repository Pro license in Azure Key Vault.                                                                                                                                                              | azureTenantId                                                                                                       |
| `secret.azure.keyvaultName`                                 | The name of the Azure Key vault containing database credentials and license. Only applicable if this chart is installed on Azure and you've stored database credentials, Nexus Repository initial admin password and your Nexus Repository Pro license in Azure Key Vault.                                                                                                       | yourazurekeyvault                                                                                                   |
| `secret.azure.useVMManagedIdentity`                         | Whether or not to use an Azure virtual machine managed identity. Only applicable if this chart is installed on Azure and you've stored database credentials, Nexus Repository initial admin password and your Nexus Repository Pro license in Azure Key Vault.                                                                                                                   | `true`                                                                                                              |
| `secret.azure.usePodIdentity`                               | Whether or not to use pod identity. Only applicable if this chart is installed on Azure and you've stored database credentials, Nexus Repository initial admin password and your Nexus Repository Pro license in Azure Key Vault.                                                                                                                                                | `false`                                                                                                             |
| `secret.azure.nexusSecret.enabled`                          | Whether the nexus secrets file should be mounted from Azure key vault                                                                                                                                                                                                                                                                                                            | `false`                                                                                                             | 
| `secret.aws.license.arn`                                    | The Amazon Resource Name for your Nexus Repository Pro license secret stored in AWS Secrets Manager. Only applicable if this chart is installed on AWS and you've stored your Nexus Repository Pro license in AWS Secrets Manager.                                                                                                                                               | `arn:aws:secretsmanager:us-east-1:000000000000:secret:nxrm-nexus-license`                                           |
| `secret.aws.adminpassword.arn`                              | The Amazon Resource Name for the Nexus Repository initial admin secret stored in AWS Secrets Manager. Only applicable if this chart is installed on AWS and you've stored your Nexus Repository initial admin password in AWS Secrets Manager.                                                                                                                                   | `arn:aws:secretsmanager:us-east-1:000000000000:secret:admin-nxrm-password`                                          |
| `secret.aws.rds.arn`                                        | The Amazon Resource Name for the database secrets stored in AWS Secrets Manager. Only applicable if this chart is installed on AWS and you've stored your database credentials in AWS Secrets Manager.                                                                                                                                                                           | `arn: arn:aws:secretsmanager:us-east-1:000000000000:secret:nxrmrds-cred-nexus`                                      |
| `secret.aws.nexusSecret.enabled`                            | Whether the nexus secrets file should be mounted from AWS secrets manager                                                                                                                                                                                                                                                                                                        | `false`                                                                                                             | 
| `secret.aws.nexusSecret.arn`                                | The Amazon Resource Name for the nexus secret JSON secret stored in AWS secrets manager                                                                                                                                                                                                                                                                                          | `arn:aws:secretsmanager:us-east-1:000000000000:secret:nxrm-nexus-secrets-file`                                      |                                                                              |
| `nexus.securityContext.runAsUser`                           | The user to run the Nexus Repository pod as                                                                                                                                                                                                                                                                                                                                      | `200`                                                                                                               |
| `nexus.properties.override`                                 | Whether or not to mount config map which contains overrides for default nexus properties                                                                                                                                                                                                                                                                                         | `false`                                                                                                             |
| `nexus.properties.data`                                     | A list of key and values to override default nexus.properties                                                                                                                                                                                                                                                                                                                    | `null`                                                                                                              |
| `nexus.extraLabels`                                         | Extra labels to apply to all objects                                                                                                                                                                                                                                                                                                                                             | `{}`                                                                                                                |
| `nexus.extraSelectorLabels`                                 | Extra selector labels to apply to all services and Nexus Repository pods. See [services.yaml](templates%2Fservices.yaml) and [statefulset.yaml](templates%2Fstatefulset.yaml)                                                                                                                                                                                                    | `{}`                                                                                                                |
| `nexus.docker.enabled`                                      | Whether or not to create a Kubernetes Service object for a given docker repository within Nexus Repository                                                                                                                                                                                                                                                                       | `false`                                                                                                             |
| `nexus.docker.type`                                         | The type of the Kubernetes Service                                                                                                                                                                                                                                                                                                                                               | `NodePort`                                                                                                          |
| `nexus.docker.protocol`                                     | The protocol                                                                                                                                                                                                                                                                                                                                                                     | TCP                                                                                                                 |
| `nexus.docker.registries`                                   | The docker registries to create ingresses and services for. See the  [ingress.yaml](templates%2Fingress.yaml) and  [services.yaml](templates%2Fservices.yaml) for how it's used                                                                                                                                                                                                  | `null`                                                                                                              |
| `config.enabled`                                            | Enable and mount a config map containing arbitrary data i.e. key value pairs                                                                                                                                                                                                                                                                                                     | `false`                                                                                                             |
| `config.data`                                               | The data for the config map                                                                                                                                                                                                                                                                                                                                                      | `{}`                                                                                                                |
| `config.mountPath`                                          | The file path to mount the config map into. Each key value pair in the config map is put on a separate line in the file                                                                                                                                                                                                                                                          | `/sonatype-nexus-conf`                                                                                              |
| `logStorage.tailSecondaryLogs`                              | When set to `true`, enables sidecar containers for tailing secondary logs (request, audit, task). Useful for centralized log collection and troubleshooting.                                                                                                                                                                                                                      | `true`                                                                                                              |
| `logStorage.combineTaskLogs`                                | When set to `true`, configures Nexus Repository to write all task logs to a single combined file (`allTasks.log`) instead of one file per task.                                                                                                                                                                                                                                  | `true`                                                                                                              |
| `ephemeralStorage.logs.enabled`                             | When set to `true`, mounts an `emptyDir` volume at `ephemeralStorage.logs.path` so that Nexus Repository logs are stored on ephemeral storage instead of the main PVC. Only enable if log forwarding (e.g., Fluent Bit → CloudWatch) is configured — ephemeral storage is wiped on pod restart.                                                                                  | `false`                                                                                                             |
| `ephemeralStorage.logs.sizeLimit`                           | The size limit for the ephemeral log volume. Kubernetes will evict the pod if usage exceeds this limit.                                                                                                                                                                                                                                                                          | `"10Gi"`                                                                                                            |
| `ephemeralStorage.logs.path`                                | The mount path for the ephemeral log volume. Must be a subdirectory of `/nexus-data` (e.g., `/nexus-data/log`). Cannot be `/nexus-data` — that path is reserved for the main PVC.                                                                                                                                                                                                | `"/nexus-data/log"`                                                                                                 |
| `ephemeralStorage.supportContent.enabled`                   | When set to `true`, mounts an `emptyDir` volume at `ephemeralStorage.supportContent.path` so that Nexus Repository support content (support zips, temp files) is stored on ephemeral storage instead of the main PVC.                                                                                                                                                            | `false`                                                                                                             |
| `ephemeralStorage.supportContent.sizeLimit`                 | The size limit for the ephemeral support content volume. Kubernetes will evict the pod if usage exceeds this limit.                                                                                                                                                                                                                                                               | `"50Gi"`                                                                                                            |
| `ephemeralStorage.supportContent.path`                      | The mount path for the ephemeral support content volume. Must be a subdirectory of `/nexus-data` (e.g., `/nexus-data/tmp`). Cannot be `/nexus-data` — that path is reserved for the main PVC.                                                                                                                                                                                    | `"/nexus-data/tmp"`                                                                                                 |
| `hpa.enabled`                                               | Whether to create a `HorizontalPodAutoscaler` resource. When `true`, `statefulset.replicaCount` must be unset and `statefulset.clustered` must be `true`.                                                                                                                                                                                                                        | `false`                                                                                                             |
| `hpa.minReplicas`                                           | Minimum number of replicas. Must be >= 2 for NXRM HA.                                                                                                                                                                                                                                                                                                                           | `2`                                                                                                                 |
| `hpa.maxReplicas`                                           | Maximum number of replicas the HPA can scale up to.                                                                                                                                                                                                                                                                                                                              | `10`                                                                                                                |
| `hpa.targetCPUUtilizationPercentage`                        | Average CPU utilization percentage across all pods that triggers scaling.                                                                                                                                                                                                                                                                                                        | `75`                                                                                                                |
| `hpa.targetMemoryUtilizationPercentage`                     | Average memory utilization percentage across all pods that triggers scaling.                                                                                                                                                                                                                                                                                                     | `80`                                                                                                                |
| `hpa.behavior.scaleDown.stabilizationWindowSeconds`         | Seconds the HPA waits before acting on a scale-down signal. Conservative default prevents thrashing.                                                                                                                                                                                                                                                                             | `300`                                                                                                               |
| `hpa.behavior.scaleDown.policies`                           | List of scale-down policies. Default limits removal to 50% of pods per 60-second window to avoid connection pool exhaustion.                                                                                                                                                                                                                                                     | `[{type: Percent, value: 50, periodSeconds: 60}]`                                                                   |
